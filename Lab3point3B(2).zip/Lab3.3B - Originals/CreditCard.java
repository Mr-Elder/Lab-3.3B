// ***************************************************************
//   CreditCard .java
//
//   Computes the monthly charge account statement 
//   for a customer of CS CARD International, a
//   credit card company
// ***************************************************************

import static java.lang.System.out;
import java.text.DecimalFormat;
import java.text.NumberFormat;

public class CreditCard
{
   public static void main (String[] args)
   {
       final double ZERO = 0.0;
       final double FIFTY = 50.0;
       final double THREE_HUNDRED = 300.0;
       final double INTEREST_RATE = 0.02;     //Credit Card Interest Rate
       final double TWENTY_PERCENT = 0.20;

       double previous_Balance;
       double additional_Charges;
       double monthly_Interest;
       double new_Balance;
       double min_Payment;
       

       previous_Balance = GetInfo.getDouble("Enter the previous months balance: ");
       additional_Charges = GetInfo.getDouble("Enter the charges for this month: ");

       // Compute the charges ...


  



		// Output the Credit Card Statement



    }
}
